public class Student {

    int id;
    String name;
    int age;
    String course;

    Student(int id, String name, int age, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.course = course;
    }

    void displayStudent() {
    System.out.println("Student ID: - Student.java:16" + id);
    System.out.println("Name: - Student.java:17" + name);
    System.out.println("Age: - Student.java:18" + age);
    System.out.println("Course: - Student.java:19" + course);}
    }


    

