public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to Student Management System! - Main.java:3");

        
        Student s1 = new Student(101, "Anu", 20, "Computer Science");
        s1.displayStudent();
      
    }
}